
document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');
    const loginMessage = document.getElementById('login-message');

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        const data = {
            email: email,
            password: password
        };

        fetch('/api/Client/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then(response => response.text()) // Cambiar response.json() a response.text()
            .then(result => {
                if (result) {
                    alert('Inicio de sesión exitoso');
                    console.log(result); // Esto mostrará el token JWT como una cadena
                    loginMessage.textContent = 'Inicio de sesión exitoso';
                    // Redirecciona o realiza alguna otra acción después del inicio de sesión exitoso.
                } else {
                    loginMessage.textContent = 'Inicio de sesión fallido. Verifique sus credenciales.';
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
});