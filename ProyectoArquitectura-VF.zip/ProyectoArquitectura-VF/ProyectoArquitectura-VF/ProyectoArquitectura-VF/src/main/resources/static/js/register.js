
// register.js

document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.getElementById('register-form');
    const registerMessage = document.getElementById('register-message');

    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const usuario = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const data = { usuario, email, password };

        console.log(data);
        fetch('/api/Client/save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result) {
                alert('Registro Exitoso')
                console.log('a');
                // registerMessage.textContent = 'Registro exitoso';
                window.location.href = './login.html';
            } else {
                // registerMessage.textContent = 'Error: ' + result.message;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});