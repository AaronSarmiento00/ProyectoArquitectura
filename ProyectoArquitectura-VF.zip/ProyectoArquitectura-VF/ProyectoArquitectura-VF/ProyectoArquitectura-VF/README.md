# ProyectoArquitectura
#easy qr code
