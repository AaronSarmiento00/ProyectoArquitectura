
document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');
    const loginMessage = document.getElementById('login-message');

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const data = { username, password };
        console.log(data)

        fetch('/api/Client/login', {
            method: 'POST', // Cambiar el método a POST
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data) // Enviar los datos en el cuerpo de la solicitud
        })
            .then(response => response.json())
            .then(result => {
                if (result) {
                    alert('Inicio de sesión exitoso')
                    console.log(result);
                    loginMessage.textContent = 'Inicio de sesión exitoso';
                    // Redirecciona o realiza alguna otra acción después del inicio de sesión exitoso.
                } else {
                    loginMessage.textContent = 'Inicio de sesión fallido. Verifique sus credenciales.';
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
});