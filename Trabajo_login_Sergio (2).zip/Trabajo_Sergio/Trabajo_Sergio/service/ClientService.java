package com.example.websocketi.service;


import com.example.websocketi.model.Client;
import com.example.websocketi.model.Fichas;
import com.example.websocketi.repository.ClientRepository;
import com.example.websocketi.repository.FichasRepository;
import com.example.websocketi.socket.Socket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;


    public List<Client> getAll(){
        return clientRepository.getAll();
    }

    public Optional<Client> getClient(int clientId) {
        return clientRepository.getClient(clientId);
    }

    public List<Client> getUserClient(String user) {
        return clientRepository.getUserClient(user);
    }

    public Client save(Client client){
        Socket.broadcast("socketClient");
        if(client.getIdClient()==null){
            return clientRepository.save(client);
        }else{
            Optional<Client> e= clientRepository.getClient(client.getIdClient());
            if(!e.isPresent()){
                return clientRepository.save(client);
            }else{
                return client;
            }
        }
    }


    public Client update(Client client){
        if(client.getIdClient()!=null){
            Optional<Client> e= clientRepository.getClient(client.getIdClient());
            if(e.isPresent()){
                if(client.getName()!=null) {
                    e.get().setName(client.getName());
                }
                if(client.getFichas()!=null){
                    e.get().getFichas().add(client.getFichas().get(0));
                }
                clientRepository.save(e.get());
                return e.get();
            }else{
                return client;
            }
        }else{
            return client;
        }
    }

    public boolean deleteClient(int clientId) {
        Boolean aBoolean = getClient(clientId).map(client -> {
            clientRepository.delete(client);
            return true;
        }).orElse(false);
        return aBoolean;
    }

    public Client getClient(String email, String password) {
        return clientRepository.getUser(email, password);
    }

}
