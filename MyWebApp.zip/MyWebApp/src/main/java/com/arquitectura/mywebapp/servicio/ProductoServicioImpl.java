package com.arquitectura.mywebapp.servicio;

import com.arquitectura.mywebapp.entidad.Producto;
import com.arquitectura.mywebapp.repositorio.ProductoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoServicioImpl implements ProductoServicio {

    @Autowired
    private ProductoRepositorio repositorio;

    @Override
    public List<Producto> listarTodosLosProductos() {
        return repositorio.findAll();
    }
}
