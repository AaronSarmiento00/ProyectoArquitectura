package com.arquitectura.mywebapp.controlador;



import com.arquitectura.mywebapp.servicio.ProductoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class ProductoControlador {


    @Autowired
    private ProductoServicio servicio;

    @GetMapping({"/productos", "/"})
    public String listarProductos(Model modelo){
        modelo.addAttribute("productos", servicio.listarTodosLosProductos());


        return "productos"; //nos retorna al archivo productos

    }

}
