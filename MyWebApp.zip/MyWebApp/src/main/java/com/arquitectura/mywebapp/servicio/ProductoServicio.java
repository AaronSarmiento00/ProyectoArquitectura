package com.arquitectura.mywebapp.servicio;


import com.arquitectura.mywebapp.entidad.Producto;


import java.util.List;


public interface ProductoServicio {

    public List<Producto> listarTodosLosProductos();


}
