package com.arquitectura.mywebapp;

import com.arquitectura.mywebapp.entidad.Producto;
import com.arquitectura.mywebapp.repositorio.ProductoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWebAppApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(MyWebAppApplication.class, args);
    }

    @Autowired
    private ProductoRepositorio repositorio;

    @Override
    public void run(String... args) throws Exception {
        Producto producto1 = new Producto("Camiseta", "Camiseta de algodón color blanco", 30000);
        repositorio.save(producto1);

        Producto producto2 = new Producto("Teléfono móvil", "Smartphone con pantalla OLED de 6 pulgadas", 1000000);
        repositorio.save(producto2);
    }

}
